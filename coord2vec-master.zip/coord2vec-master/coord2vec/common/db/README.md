# DB Utils

In this module we hold all DB related functions, such as connectors.

We currently focus on **SqlAlchemy** for access to the DB, we mostly assume working on an **Oracle DB**.