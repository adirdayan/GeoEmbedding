# Geographic Utils

In this module we hold all geographic related utility functions, such as the GeoMap object.